# -------------------------------------------------------------------------------
# TASK 01: Example 1: US SENATE DATASET - PLOT 4 NETWORKS
# TASK 02: Example 1: ANOMALY DETECTION USING THE FRAMEWORK
# TASK 03: Example 2: UCI REPOSITORY - PLOT NETWORKS
# TASK 04: Example 2: UCI REPOSITORY - ANOMALY DETECTION
# TASK 05: Example 3: CANADIAN VOTING - PLOT NETWORKS
# TASK 06: Example 3: CANADIAN VOTING - ANOMALY DETECTION
# TASK 07: Example 4: US PRESIDENTIAL BLOGPOSTS - PLOT NETWORKS
# TASK 08: Example 5: US PRESIDENTIAL BLOGPOSTS -  ANOMALY DETECTION
# TASK 09: Example 6: PHYSICS CITATIONS DATASET - ANOMALY DETECTION
# TASK 10: Example 7: PHYSICS CITATIONS DATASET - PLOT NETWORKS
# TASK 11: Example 8: TWITTER SECURITY NETWORK - ANOMALY DETECTION
# TASK 12: Example 9: TWITTER SECURITY NETWORK -  PLOT NETWORKS
# -------------------------------------------------------------------------------


library(fpp3)
library(GGally)
library(lookout)
library(stray)
library(pcaPP)
library(VCERGM)
library(igraph)
library(rlang)
library(tnet)
library(dnr)
library(ggraph)
library(gridExtra)
library(latex2exp)

# > sessionInfo()
# R version 4.2.1 (2022-06-23)
# Platform: x86_64-apple-darwin17.0 (64-bit)
# Running under: macOS Ventura 13.4.1
#
# Matrix products: default
# LAPACK: /Library/Frameworks/R.framework/Versions/4.2/Resources/lib/libRlapack.dylib
#
# locale:
#   [1] en_US.UTF-8/en_US.UTF-8/en_US.UTF-8/C/en_US.UTF-8/en_US.UTF-8
#
# attached base packages:
#   [1] stats     graphics  grDevices utils     datasets  methods   base
#
# other attached packages:
#   [1] latex2exp_0.9.4   gridExtra_2.3     ggraph_2.0.6      dnr_0.3.5         ergm_4.2.2
# [6] network_1.17.2    tnet_3.0.16       survival_3.3-1    rlang_1.1.1       igraph_1.3.4
# [11] VCERGM_0.0.0.9000 pcaPP_2.0-2       stray_0.1.1       lookout_0.1.4     GGally_2.1.2
# [16] fable_0.3.1       feasts_0.2.2      fabletools_0.3.2  tsibbledata_0.4.0 tsibble_1.1.1
# [21] lubridate_1.8.0   fpp3_0.4.0        forcats_0.5.1     stringr_1.5.0     dplyr_1.1.2
# [26] purrr_1.0.1       readr_2.1.2       tidyr_1.3.0       tibble_3.2.1      tidyverse_1.3.2
# [31] ggplot2_3.4.0
#
# loaded via a namespace (and not attached):
#   [1] googledrive_2.0.0       colorspace_2.0-3        ellipsis_0.3.2          fs_1.5.2
# [5] rstudioapi_0.13         farver_2.1.1            graphlayouts_0.8.1      ggrepel_0.9.1
# [9] fansi_1.0.3             mvtnorm_1.1-3           xml2_1.3.3              splines_4.2.1
# [13] cachem_1.0.6            robustbase_0.95-0       polyclip_1.10-0         jsonlite_1.8.0
# [17] broom_1.0.0             anytime_0.3.9           dbplyr_2.2.1            ggforce_0.3.3
# [21] compiler_4.2.1          httr_1.4.3              backports_1.4.1         assertthat_0.2.1
# [25] Matrix_1.5-3            fastmap_1.1.0           gargle_1.2.0            cli_3.4.1
# [29] tweenr_1.0.2            tools_4.2.1             coda_0.19-4             gtable_0.3.0
# [33] glue_1.6.2              rappdirs_0.3.3          Rcpp_1.0.9              rle_0.9.2
# [37] cellranger_1.1.0        statnet.common_4.6.0    vctrs_0.6.2             trust_0.1-8
# [41] rvest_1.0.2             lifecycle_1.0.3         googlesheets4_1.0.1     DEoptimR_1.0-11
# [45] MASS_7.3-57             scales_1.2.0            tidygraph_1.2.1         hms_1.1.1
# [49] parallel_4.2.1          RColorBrewer_1.1-3      memoise_2.0.1           reshape_0.8.9
# [53] stringi_1.7.8           pkgconfig_2.0.3         distributional_0.3.0    lpSolveAPI_5.5.2.0-17.8
# [57] lattice_0.20-45         labeling_0.4.2          tidyselect_1.2.0        plyr_1.8.7
# [61] magrittr_2.0.3          R6_2.5.1                generics_0.1.3          DBI_1.1.3
# [65] pillar_1.9.0            haven_2.5.0             withr_2.5.0             modelr_0.1.8
# [69] crayon_1.5.1            utf8_1.2.2              tzdb_0.3.0              viridis_0.6.2
# [73] grid_4.2.1              readxl_1.4.0            FNN_1.1.3.1             reprex_2.0.1
# [77] digest_0.6.29           munsell_0.5.0           viridisLite_0.4.0

# -------------------------------------------------------------------------------
# Example 1: US SENATE DATASET - PLOT 4 NETWORKS
# -------------------------------------------------------------------------------
networks = Rollcall$networks
attr = Rollcall$attr

# FIGURE 17 IN THE PAPER
# Plotting
network_40 <- networks[[1]]
gr40 <- igraph::graph_from_adjacency_matrix(network_40)
gr40 <- set_vertex_attr(gr40, "party", value = attr[[1]])
plot(gr40, vertex.color = c("blue", "red")[as.numeric(as.factor(vertex_attr(gr40, "party")))])

layout <- create_layout(gr40, layout = 'igraph', algorithm = 'nicely')
g1 <- ggraph(layout) +
  geom_edge_link() +
  geom_node_point(aes(color = party)) +
  theme_bw()  +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.ticks = element_blank(),
        axis.text = element_blank() ) +
  xlab("") +
  ylab("") +
  scale_color_manual(values = c("blue", "red")) +
  ggtitle(TeX("$40^{th}$ Congress"))

g1

tt <- 25
networkt <- networks[[tt]]
grt <- igraph::graph_from_adjacency_matrix(networkt)
grt <- set_vertex_attr(grt, "party", value = attr[[tt]])
layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g2 <- ggraph(layout) +
  geom_edge_link() +
  geom_node_point(aes(color = party)) +
  theme_bw()  +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.ticks = element_blank(),
        axis.text = element_blank() ) +
  xlab("") +
  ylab("") +
  scale_color_manual(values = c("blue", "red")) +
  ggtitle(TeX("$64^{th}$ Congress"))

g2

tt <- 50
networkt <- networks[[tt]]
grt <- igraph::graph_from_adjacency_matrix(networkt)
grt <- set_vertex_attr(grt, "party", value = attr[[tt]])
layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g3 <- ggraph(layout) +
  geom_edge_link() +
  geom_node_point(aes(color = party)) +
  theme_bw()  +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.ticks = element_blank(),
        axis.text = element_blank() ) +
  xlab("") +
  ylab("") +
  scale_color_manual(values = c("blue", "red")) +
  ggtitle(TeX("$89^{th}$ Congress"))

g3

network_113 <- networks[[74]]
gr113 <- igraph::graph_from_adjacency_matrix(network_113)
gr113 <- set_vertex_attr(gr113, "party", value = attr[[74]])
plot(gr113, vertex.color = c("blue", "red")[as.numeric(as.factor(vertex_attr(gr113, "party")))])

layout <- create_layout(gr113, layout = 'igraph', algorithm = 'nicely')
#create_layout(gr40, layout = 'kk')
g4 <- ggraph(layout) +
  geom_edge_link() +
  geom_node_point(aes(color = party)) +
  theme_bw()  +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.ticks = element_blank(),
        axis.text = element_blank() ) +
  xlab("") +
  ylab("") +
  scale_color_manual(values = c("blue", "red")) +
  ggtitle(TeX("$113^{th}$ Congress"))

g4

gridExtra::grid.arrange(g1, g2, g3, g4, nrow = 2)
# Figure 17

# -------------------------------------------------------------------------------
# TASK 02: Example 1: ANOMALY DETECTION USING THE FRAMEWORK
# -------------------------------------------------------------------------------
dat <- read.csv('Senator_Voting_Anomaly_Scores.csv', header = FALSE)
methods <- read.csv('Senator_Voting_Different_Methods.csv', header = FALSE)
colnames(methods) <- c("Embedding", "Temporal", "Anomaly")
methods2 <- methods %>%
  mutate(name = paste('V',1:56, sep=""))

dat_embed <- data.frame(Embedding = 1:4, Embedding_Method = c('GL2Vec', 'FGSD', 'Graph2Vec', 'Features'))
dat_temporal <- data.frame(Temporal = 1:2, Temporal_Method = c('LSTM', 'ARIMA'))
dat_anomaly <- data.frame(Anomaly = 1:7, Anomaly_Method = c('Isolation', 'LOF', 'DBSCAN', 'KNN', 'OCSVM', 'Autoencoder', 'stray'))



mins <- apply(dat, 2, max)
dat1 <- sweep(data.matrix(dat), 2, mins)

dat2 <- dat1 %>%
  as.data.frame() %>%
  mutate(index = 1:74) %>%
  relocate(index,) %>%
  pivot_longer(cols = 2:57)

dat3 <- left_join(dat2, methods2) %>%
  left_join(dat_embed) %>%
  left_join(dat_temporal) %>%
  left_join(dat_anomaly) %>%
  rename(Embedding_Num = Embedding) %>%
  rename(Embedding = Embedding_Method) %>%
  rename(Temporal_Num = Temporal) %>%
  rename(Temporal = Temporal_Method) %>%
  rename(Anomaly_Num = Anomaly) %>%
  rename(Anomaly = Anomaly_Method)

dat3 <- dat3 %>%
  mutate(Congress = index + 39)

g1 <- ggplot(dat3, aes(x = Congress, y = value, group = name)) +
  geom_line(aes(color = Anomaly)) +
  xlab("Congress") +
  ylab("Anomaly Score") +
  scale_color_brewer(palette="Dark2") +
  theme_bw()

g2 <- ggplot(dat3, aes(x = Congress, y = value, group = name)) +
  geom_line(aes(color = Embedding)) +
  xlab("Congress") +
  ylab("Anomaly Score") +
  scale_color_brewer(palette="Dark2") +
  theme_bw()

g3 <- ggplot(dat3, aes(x = Congress, y = value, group = name)) +
  geom_line(aes(color = Temporal)) +
  xlab("Congress") +
  ylab("Anomaly Score") +
  scale_color_brewer(palette="Dark2") +
  theme_bw()

lowest3 <- apply(dat, 2, function(x) order(x)[1:3])
anom_score_low3 <- table(as.vector(lowest3))
dat4 <- data.frame(senate = 40:113, anomaly_times = 0 )
dat4[as.numeric(names(anom_score_low3)), 2] <-  anom_score_low3

g4 <- ggplot(dat4, aes(senate, anomaly_times)) +
  geom_point() +
  geom_line() +
  xlab("Congress") +
  ylab("Anomalous Frequency")


gridExtra::grid.arrange(g2, g3, g1,  g4)
# Figure 18
# Senate_Voting_1 8 X 4 inches

# -------------------------------------------------------------------------------
# TASK 03: Example 2: UCI REPOSITORY - PLOT NETWORKS
# -------------------------------------------------------------------------------

data(tnet)
dat <- tnet::OnlineSocialNetwork.n1899.lnet
head(dat)
dat$t <-  as_datetime(dat$t)
dat$date <- as_date(dat$t)
length(which(dat$i == dat$j))
dat2 <- dat

dat3 <- dat2[ ,c("i", "j", "date")]
len <-  length(unique(dat3$date))
unique_dates <- unique(dat3$date)
num_networks <- length(unique_dates)

mat_list <- list()
for(i in 1:num_networks){
  nn <- unique_dates[i]
  inds <- which( dat3$date == nn )
  datwin <- dat3[inds, 1:2]
  gr <- graph_from_data_frame(datwin)
  mat_list[[i]] <- as_adjacency_matrix(gr)
}


tt <- 24
networkt <- mat_list[[tt]]
grt <- igraph::graph_from_adjacency_matrix(networkt)
layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g1 <- ggraph(layout) +
  geom_edge_link(edge_colour = "grey66",
                 arrow = arrow(
                   angle = 10,
                   length = unit(0.1, "inches"),
                   ends = "last",
                   type = "closed"
                 )) +
  geom_node_point(col = "black", show.legend = FALSE) +
  scale_size(range = c(3, 11)) +
  theme_graph() +
  theme_bw()  +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.ticks = element_blank(),
        axis.text = element_blank() ) +
  xlab("") +
  ylab("") +
  ggtitle(paste("Day", tt))

g1

tt <- 25
networkt <- mat_list[[tt]]
grt <- igraph::graph_from_adjacency_matrix(networkt)
layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g2 <- ggraph(layout) +
  geom_edge_link(edge_colour = "grey66",
                 arrow = arrow(
                   angle = 10,
                   length = unit(0.1, "inches"),
                   ends = "last",
                   type = "closed"
                 )) +
  geom_node_point(col = "black", show.legend = FALSE) +
  scale_size(range = c(3, 11)) +
  theme_graph() +
  theme_bw()  +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.ticks = element_blank(),
        axis.text = element_blank() ) +
  xlab("") +
  ylab("") +
  ggtitle(paste("Day", tt))

g2

tt <- 26
networkt <- mat_list[[tt]]
grt <- igraph::graph_from_adjacency_matrix(networkt)
layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g3 <- ggraph(layout) +
  geom_edge_link(edge_colour = "grey66",
                 arrow = arrow(
                   angle = 10,
                   length = unit(0.1, "inches"),
                   ends = "last",
                   type = "closed"
                 )) +
  geom_node_point(col = "black", show.legend = FALSE) +
  scale_size(range = c(3, 11)) +
  theme_graph() +
  theme_bw()  +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.ticks = element_blank(),
        axis.text = element_blank() ) +
  xlab("") +
  ylab("") +
  ggtitle(paste("Day", tt))

g3


tt <- 89
networkt <- mat_list[[tt]]
grt <- igraph::graph_from_adjacency_matrix(networkt)
layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g4 <- ggraph(layout) +
  geom_edge_link(edge_colour = "grey66",
                 arrow = arrow(
                   angle = 10,
                   length = unit(0.1, "inches"),
                   ends = "last",
                   type = "closed"
                 )) +
  geom_node_point(col = "black", show.legend = FALSE) +
  scale_size(range = c(3, 11)) +
  theme_graph() +
  theme_bw()  +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.ticks = element_blank(),
        axis.text = element_blank() ) +
  xlab("") +
  ylab("") +
  ggtitle(paste("Day", tt))

g4

tt <- 90
networkt <- mat_list[[tt]]
grt <- igraph::graph_from_adjacency_matrix(networkt)
layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g5 <- ggraph(layout) +
  geom_edge_link(edge_colour = "grey66",
                 arrow = arrow(
                   angle = 10,
                   length = unit(0.1, "inches"),
                   ends = "last",
                   type = "closed"
                 )) +
  geom_node_point(col = "black", show.legend = FALSE) +
  scale_size(range = c(3, 11)) +
  theme_graph() +
  theme_bw()  +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.ticks = element_blank(),
        axis.text = element_blank() ) +
  xlab("") +
  ylab("") +
  ggtitle(paste("Day", tt))

g5

tt <- 91
networkt <- mat_list[[tt]]
grt <- igraph::graph_from_adjacency_matrix(networkt)
layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g6 <- ggraph(layout) +
  geom_edge_link(edge_colour = "grey66",
                 arrow = arrow(
                   angle = 10,
                   length = unit(0.1, "inches"),
                   ends = "last",
                   type = "closed"
                 )) +
  geom_node_point(col = "black", show.legend = FALSE) +
  scale_size(range = c(3, 11)) +
  theme_graph() +
  theme_bw()  +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.ticks = element_blank(),
        axis.text = element_blank() ) +
  xlab("") +
  ylab("") +
  ggtitle(paste("Day", tt))

g6

gridExtra::grid.arrange(g1, g2, g3, g4, g5, g6, nrow = 2)
# Figure 21

# -------------------------------------------------------------------------------
# TASK 04: Example 2: UCI REPOSITORY - ANOMALY DETECTION
# -------------------------------------------------------------------------------
dat <- read.csv('UCI_Message_Anomaly_Scores.csv', header = FALSE)
methods <- read.csv('UCI_Message_Different_Methods.csv', header = FALSE)
colnames(methods) <- c("Embedding", "Temporal", "Anomaly")
methods2 <- methods %>%
  mutate(name = paste('V',1:56, sep=""))

dat_embed <- data.frame(Embedding = 1:4, Embedding_Method = c('GL2Vec', 'FGSD', 'Graph2Vec', 'Features'))
dat_temporal <- data.frame(Temporal = 1:2, Temporal_Method = c('LSTM', 'ARIMA'))
dat_anomaly <- data.frame(Anomaly = 1:7, Anomaly_Method = c('Isolation', 'LOF', 'DBSCAN', 'KNN', 'OCSVM', 'Autoencoder', 'stray'))

mins <- apply(dat, 2, max)
dat1 <- sweep(data.matrix(dat), 2, mins)

dat2 <- dat1 %>%
  as.data.frame() %>%
  mutate(index = 1:dim(dat1)[1]) %>%
  relocate(index,) %>%
  pivot_longer(cols = 2:57)

dat3 <- left_join(dat2, methods2) %>%
  left_join(dat_embed) %>%
  left_join(dat_temporal) %>%
  left_join(dat_anomaly) %>%
  rename(Embedding_Num = Embedding) %>%
  rename(Embedding = Embedding_Method) %>%
  rename(Temporal_Num = Temporal) %>%
  rename(Temporal = Temporal_Method) %>%
  rename(Anomaly_Num = Anomaly) %>%
  rename(Anomaly = Anomaly_Method)

dat3 <- dat3 %>%
  mutate(Day = index)

g1 <- ggplot(dat3, aes(x = Day, y = value, group = name)) +
  geom_line(aes(color = Anomaly)) +
  xlab("Day") +
  ylab("Anomaly Score") +
  scale_color_brewer(palette="Dark2") +
  theme_bw()

g2 <- ggplot(dat3, aes(x = Day, y = value, group = name)) +
  geom_line(aes(color = Embedding)) +
  xlab("Day") +
  ylab("Anomaly Score") +
  scale_color_brewer(palette="Dark2") +
  theme_bw()

g3 <- ggplot(dat3, aes(x = Day, y = value, group = name)) +
  geom_line(aes(color = Temporal)) +
  xlab("Day") +
  ylab("Anomaly Score") +
  scale_color_brewer(palette="Dark2") +
  theme_bw()

lowest3 <- apply(dat, 2, function(x) order(x)[1:3])
anom_score_low3 <- table(as.vector(lowest3))
dat4 <- data.frame(Day = 1:dim(dat1)[1], date = unique_dates, anomaly_times = 0 )
dat4[as.numeric(names(anom_score_low3)), 3] <-  anom_score_low3

g4 <- ggplot(dat4, aes(Day, anomaly_times)) +
  geom_point() +
  geom_line() +
  xlab("Day") +
  ylab("Anomalous Frequency")


gridExtra::grid.arrange(g2, g3, g1,  g4)
# Figure 20
# UCI_Message_2 8 X 4 inches

dat4 %>%
  arrange(desc(anomaly_times))

#     Day       date anomaly_times
# 1    25 2004-05-08            26
# 2    90 2004-07-12            25

# -------------------------------------------------------------------------------
# TASK 05: Example 3: CANADIAN VOTING - PLOT NETWORKS
# -------------------------------------------------------------------------------
dat <- read.csv("Canadian_Votes_Edgelist.csv", header = FALSE)
unique(dat$V2)
colnames(dat) <- c("Year", "From", "To", "Weight")
years <- unique(dat$Year)
num_years <- length(years)

mat_list <- list()

for(i in 1:num_years){
  yearr <- years[i]
  datwin <- dat[dat$Year == yearr, 2:3]
  gr <- graph_from_data_frame(datwin)
  mat_list[[i]] <- as_adjacency_matrix(gr)
}

tt <- 1
yearr <- tt +  2005
networkt <- mat_list[[tt]]
grt <- igraph::graph_from_adjacency_matrix(networkt)
layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g1 <- ggraph(layout) +
  geom_edge_link(edge_colour = "grey66") +
  geom_node_point(col = "black", show.legend = FALSE) +
  scale_size(range = c(3, 11)) +
  theme_graph() +
  theme_bw()  +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.ticks = element_blank(),
        axis.text = element_blank() ) +
  xlab("") +
  ylab("") +
  ggtitle(yearr)
g1

tt <- 3
yearr <- tt +  2005
networkt <- mat_list[[tt]]
grt <- igraph::graph_from_adjacency_matrix(networkt)
layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g2 <- ggraph(layout) +
  geom_edge_link(edge_colour = "grey66") +
  geom_node_point(col = "black", show.legend = FALSE) +
  scale_size(range = c(3, 11)) +
  theme_graph() +
  theme_bw()  +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.ticks = element_blank(),
        axis.text = element_blank() ) +
  xlab("") +
  ylab("") +
  ggtitle(yearr)
g2


tt <- 6
yearr <- tt +  2005
networkt <- mat_list[[tt]]
grt <- igraph::graph_from_adjacency_matrix(networkt)
layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g3 <- ggraph(layout) +
  geom_edge_link(edge_colour = "grey66") +
  geom_node_point(col = "black", show.legend = FALSE) +
  scale_size(range = c(3, 11)) +
  theme_graph() +
  theme_bw()  +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.ticks = element_blank(),
        axis.text = element_blank() ) +
  xlab("") +
  ylab("") +
  ggtitle(yearr)
g3


tt <- 10
yearr <- tt +  2005
networkt <- mat_list[[tt]]
grt <- igraph::graph_from_adjacency_matrix(networkt)
layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g4 <- ggraph(layout) +
  geom_edge_link(edge_colour = "grey66") +
  geom_node_point(col = "black", show.legend = FALSE) +
  scale_size(range = c(3, 11)) +
  theme_graph() +
  theme_bw()  +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.ticks = element_blank(),
        axis.text = element_blank() ) +
  xlab("") +
  ylab("") +
  ggtitle(yearr)
g4


tt <- 12
yearr <- tt +  2005
networkt <- mat_list[[tt]]
grt <- igraph::graph_from_adjacency_matrix(networkt)
layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g5 <- ggraph(layout) +
  geom_edge_link(edge_colour = "grey66") +
  geom_node_point(col = "black", show.legend = FALSE) +
  scale_size(range = c(3, 11)) +
  theme_graph() +
  theme_bw()  +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.ticks = element_blank(),
        axis.text = element_blank() ) +
  xlab("") +
  ylab("") +
  ggtitle(yearr)
g5


tt <- 14
yearr <- tt +  2005
networkt <- mat_list[[tt]]
grt <- igraph::graph_from_adjacency_matrix(networkt)
layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g6 <- ggraph(layout) +
  geom_edge_link(edge_colour = "grey66") +
  geom_node_point(col = "black", show.legend = FALSE) +
  scale_size(range = c(3, 11)) +
  theme_graph() +
  theme_bw()  +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.ticks = element_blank(),
        axis.text = element_blank() ) +
  xlab("") +
  ylab("") +
  ggtitle(yearr)
g6


gridExtra::grid.arrange(g1, g2, g3, g4, g5, g6, nrow = 2)
# Figure 23

# -------------------------------------------------------------------------------
# TASK 06: Example 3: CANADIAN VOTING - ANOMALY DETECTION
# -------------------------------------------------------------------------------
dat <- read.csv('Canadian_Voting_Anomaly_Scores.csv', header = FALSE)
methods <- read.csv('Canadian_Voting_Different_Methods.csv', header = FALSE)
colnames(methods) <- c("Embedding", "Temporal", "Anomaly")
methods2 <- methods %>%
  mutate(name = paste('V',1:56, sep=""))

dat_embed <- data.frame(Embedding = 1:4, Embedding_Method = c('GL2Vec', 'FGSD', 'Graph2Vec', 'Features'))
dat_temporal <- data.frame(Temporal = 1:2, Temporal_Method = c('LSTM', 'ARIMA'))
dat_anomaly <- data.frame(Anomaly = 1:7, Anomaly_Method = c('Isolation', 'LOF', 'DBSCAN', 'KNN', 'OCSVM', 'Autoencoder', 'stray'))

mins <- apply(dat, 2, max)
dat1 <- sweep(data.matrix(dat), 2, mins)

lowest3 <- apply(dat, 2, function(x) order(x)[1:3])
anom_score_low3 <- table(as.vector(lowest3))
year <- 2005 + 1:dim(dat1)[1]
dat4 <- data.frame(Year = year, anomaly_times = 0 )
dat4[as.numeric(names(anom_score_low3)), 2] <-  anom_score_low3

g4 <- ggplot(dat4, aes(Year, anomaly_times)) +
  geom_point() +
  geom_line() +
  xlab("Year") +
  ylab("Anomalous Frequency")
g4
# Figure 24(a)

# -------------------------------------------------------------------------------
# TASK 07: Example 4: US PRESIDENTIAL BLOGPOSTS - PLOT NETWORKS
# -------------------------------------------------------------------------------
data(rdNets)
party_name <- c(rep("Democrat", 34), rep("Republican", 13))
party_name[23] <- "common"
networks <- rdNets

num_networks <- length(networks)
mat_list <- list()
attr <- list()

k <- 1
# Networks 345 and 346 are empty.
for(i in 1:num_networks){
  if(class(networks[[i]]) == 'network'){
    mat_list[[k]] <- as.matrix.network.adjacency(networks[[i]])
    attr[[k]] <- party_name
    k <- k +1
  }
}


dates <- seq(as.Date("2004-07-22"), as.Date("2004-11-19"), by = 1, each = 4 )
dates <- rep(dates, each = 4 )
dates
num_networks

dates <- dates[ -c(345,346)]

tt <- 10
day <- dates[tt]
networkt <- mat_list[[tt]]
grt <- igraph::graph_from_adjacency_matrix(networkt)
grt <- set_vertex_attr(grt, "party", value = attr[[tt]])

layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g1 <- ggraph(layout) +
  geom_edge_link() +
  geom_node_point(aes(color = party), size = 2) +
  geom_edge_link(edge_colour = "grey66") +
  theme_bw()  +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.ticks = element_blank(),
        axis.text = element_blank() ) +
  xlab("") +
  ylab("") +
  scale_color_manual(values = c("yellow", "blue", "red")) +
  ggtitle(day)

g1



tt <- 100
day <- dates[tt]
networkt <- mat_list[[tt]]
grt <- igraph::graph_from_adjacency_matrix(networkt)
grt <- set_vertex_attr(grt, "party", value = attr[[tt]])

layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g2 <- ggraph(layout) +
  geom_edge_link() +
  geom_node_point(aes(color = party), size = 2) +
  geom_edge_link(edge_colour = "grey66") +
  theme_bw()  +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.ticks = element_blank(),
        axis.text = element_blank() ) +
  xlab("") +
  ylab("") +
  scale_color_manual(values = c("yellow", "blue", "red")) +
  ggtitle(day)

g2


tt <- 150
day <- dates[tt]
networkt <- mat_list[[tt]]
grt <- igraph::graph_from_adjacency_matrix(networkt)
grt <- set_vertex_attr(grt, "party", value = attr[[tt]])

layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g3 <- ggraph(layout) +
  geom_edge_link() +
  geom_node_point(aes(color = party), size = 2) +
  geom_edge_link(edge_colour = "grey66") +
  theme_bw()  +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.ticks = element_blank(),
        axis.text = element_blank() ) +
  xlab("") +
  ylab("") +
  scale_color_manual(values = c("yellow", "blue", "red")) +
  ggtitle(day)

g3


tt <- 246
day <- dates[tt]
networkt <- mat_list[[tt]]
grt <- igraph::graph_from_adjacency_matrix(networkt)
grt <- set_vertex_attr(grt, "party", value = attr[[tt]])

layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g4 <- ggraph(layout) +
  geom_edge_link() +
  geom_node_point(aes(color = party), size = 2) +
  geom_edge_link(edge_colour = "grey66") +
  theme_bw()  +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "none",
        axis.ticks = element_blank(),
        axis.text = element_blank() ) +
  xlab("") +
  ylab("") +
  scale_color_manual(values = c("yellow", "blue", "red")) +
  ggtitle(day)

g4


gridExtra::grid.arrange(g1, g2, g3, g4, nrow = 2)
# Figure 25

# -------------------------------------------------------------------------------
# TASK 08: Example 5: US PRESIDENTIAL BLOGPOSTS -  ANOMALY DETECTION
# -------------------------------------------------------------------------------
dat <- read.csv('US_Presidential_Blogs_Anomaly_Scores.csv', header = FALSE)
methods <- read.csv('US_Presidential_Blogs_Different_Methods.csv', header = FALSE)
colnames(methods) <- c("Embedding", "Temporal", "Anomaly")
methods2 <- methods %>%
  mutate(name = paste('V',1:56, sep=""))

dat_embed <- data.frame(Embedding = 1:4, Embedding_Method = c('GL2Vec', 'FGSD', 'Graph2Vec', 'Features'))
dat_temporal <- data.frame(Temporal = 1:2, Temporal_Method = c('LSTM', 'ARIMA'))
dat_anomaly <- data.frame(Anomaly = 1:7, Anomaly_Method = c('Isolation', 'LOF', 'DBSCAN', 'KNN', 'OCSVM', 'Autoencoder', 'stray'))

mins <- apply(dat, 2, max)
dat1 <- sweep(data.matrix(dat), 2, mins)

lowest3 <- apply(dat, 2, function(x) order(x)[1:3])
anom_score_low3 <- table(as.vector(lowest3))
dat4 <- data.frame(Dates = dates, anomaly_times = 0 )
dat4[as.numeric(names(anom_score_low3)), 2] <-  anom_score_low3

g4 <- ggplot(dat4, aes(Dates, anomaly_times)) +
  geom_point() +
  geom_line() +
  xlab("Date") +
  ylab("Anomalous Frequency")
g4
# Figure 26(a)

inds <- order(dat4$anomaly_times, decreasing = TRUE)[1:4]
# 453 246 458 17
dat4[inds ,]
# > dat4[inds ,]
# Dates anomaly_times
# 453 2004-11-12            27
# 246 2004-09-21            20
# 458 2004-11-13            20
# 17  2004-07-26            15


# -------------------------------------------------------------------------------
# TASK 09: Example 6: PHYSICS CITATIONS DATASET - ANOMALY DETECTION
# -------------------------------------------------------------------------------
library(lubridate)
# > packageVersion("lubridate")
# [1] ‘1.8.0’

dat <- read.csv('Physics_Citations_Anomaly_Scores.csv', header = FALSE)
methods <- read.csv('Physics_Citations_Different_Methods.csv', header = FALSE)
months <- read.csv('Physics_Citations_Months.csv')
months <- months[ ,2]

colnames(methods) <- c("Embedding", "Temporal", "Anomaly")
methods2 <- methods %>%
  mutate(name = paste('V',1:56, sep=""))

dat_embed <- data.frame(Embedding = 1:4, Embedding_Method = c('GL2Vec', 'FGSD', 'Graph2Vec', 'Features'))
dat_temporal <- data.frame(Temporal = 1:2, Temporal_Method = c('LSTM', 'ARIMA'))
dat_anomaly <- data.frame(Anomaly = 1:7, Anomaly_Method = c('Isolation', 'LOF', 'DBSCAN', 'KNN', 'OCSVM', 'Autoencoder', 'stray'))

mins <- apply(dat, 2, max)
dat1 <- sweep(data.matrix(dat), 2, mins)

lowest3 <- apply(dat, 2, function(x) order(x)[1:3])
anom_score_low3 <- table(as.vector(lowest3))
dat4 <- data.frame(Month = ym(months), anomaly_times = 0 )
dat4[as.numeric(names(anom_score_low3)), 2] <-  anom_score_low3
dat5 <- dat4[-c(1:4,119), ] # removing these entries due to data issues
# early networks do not have many edges due to missing history - discussed in paper
# last network doesn't have all the citations in the month


g4 <- ggplot(dat5, aes(Month, anomaly_times)) +
  geom_point() +
  geom_line() +
  ylab("Anomalous Frequency")
g4
# Figure 28(a)

inds <- order(dat5$anomaly_times, decreasing = TRUE)[1:7]
dat5[inds ,]

# > dat5[inds ,]
# Month anomaly_times
# 114 2001-10-01             6
# 58  1997-02-01             5
# 59  1997-03-01             5
# 118 2002-02-01             5
# 62  1997-06-01             4
# 78  1998-10-01             4
# 116 2001-12-01             4

# -------------------------------------------------------------------------------
# TASK 10: Example 7: PHYSICS CITATIONS DATASET - PLOT NETWORKS
# -------------------------------------------------------------------------------

times <- read.csv("cit-HepPh-dates_2.csv")
df2 <- read.csv("Cit-HepPh-Dynamic_char_fixed_1.csv")
df3 <- df2 %>%
  mutate(
    Date = ymd(Date),
    Month_Yr = format_ISO8601(Date, precision = "ym")
  )
times_df <- times %>%
  mutate(
    Date = ymd(Date),
    Month_Yr = format_ISO8601(Date, precision = "ym")
  )

num_networks <- length(unique(df3$Month_Yr))
mat <- matrix(0, nrow = num_networks, ncol = 24)
months <- sort(unique(df3$Month_Yr))

grlist <- c()
for(win in 1:num_networks){
  inds <- which(df3$Month_Yr %in% months[win])
  datwin <- df3[inds, ]
  gr <- graph_from_data_frame(datwin)
  grlist[[win]] <- gr
}

jj <- 10
grt <- grlist[[jj]]
layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g1 <- ggraph(layout) +
  geom_edge_link(edge_colour = "grey66") +
  geom_node_point(col = "black", show.legend = FALSE) +
  theme_bw()  +
  xlab("") +
  ylab("") +
  ggtitle(months[jj]) +
  theme(legend.position = "none")

jj <- 50
grt <- grlist[[jj]]
layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g2 <- ggraph(layout) +
  geom_edge_link(edge_colour = "grey66") +
  geom_node_point(col = "black", show.legend = FALSE) +
  theme_bw()  +
  xlab("") +
  ylab("") +
  ggtitle(months[jj]) +
  theme(legend.position = "none")


jj <- 100
grt <- grlist[[jj]]
layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g3 <- ggraph(layout) +
  geom_edge_link(edge_colour = "grey66") +
  geom_node_point(col = "black", show.legend = FALSE) +
  theme_bw()  +
  xlab("") +
  ylab("") +
  ggtitle(months[jj]) +
  theme(legend.position = "none")


gridExtra::grid.arrange(g1, g2, g3, nrow = 1)
# Figure 27

# -------------------------------------------------------------------------------
# TASK 11: Example 8: TWITTER SECURITY NETWORK - ANOMALY DETECTION
# -------------------------------------------------------------------------------
library(lubridate)

dat <- read.csv('Twitter_Anomaly_Scores.csv', header = FALSE)
methods <- read.csv('Twitter_Different_Methods.csv', header = FALSE)
dates <- read.csv("Twitter_Dates.csv")
dates <- dates[ ,2]

colnames(methods) <- c("Embedding", "Temporal", "Anomaly")
methods2 <- methods %>%
  mutate(name = paste('V',1:56, sep=""))

dat_embed <- data.frame(Embedding = 1:4, Embedding_Method = c('GL2Vec', 'FGSD', 'Graph2Vec', 'Features'))
dat_temporal <- data.frame(Temporal = 1:2, Temporal_Method = c('LSTM', 'ARIMA'))
dat_anomaly <- data.frame(Anomaly = 1:7, Anomaly_Method = c('Isolation', 'LOF', 'DBSCAN', 'KNN', 'OCSVM', 'Autoencoder', 'stray'))

mins <- apply(dat, 2, max)
dat1 <- sweep(data.matrix(dat), 2, mins)

lowest3 <- apply(dat, 2, function(x) order(x)[1:3])
anom_score_low3 <- table(as.vector(lowest3))
dat4 <- data.frame(Date = ymd(dates), anomaly_times = 0 )
dat4[as.numeric(names(anom_score_low3)), 2] <-  anom_score_low3


g4 <- ggplot(dat4, aes(Date, anomaly_times)) +
  geom_point() +
  geom_line() +
  ylab("Anomalous Frequency")
g4
# Figure 29(a)

inds <- order(dat4$anomaly_times, decreasing = TRUE)[1:7]
dat4[inds ,]


# -------------------------------------------------------------------------------
# TASK 12: Example : TWITTER SECURITY NETWORK -  PLOT NETWORKS
# -------------------------------------------------------------------------------

# This is the file you need to download from https://odds.cs.stonybrook.edu/twittersecurity-dataset/
# Please change filepath accordingly

filename <-  '/Users/kan092/Library/CloudStorage/OneDrive-CSIRO/Documents/Research/Networks/Datasets/Twitter/Twitter_May_Aug_2014_TerrorSecurity_resolved.txt'
datori <- read.csv(filename, sep=" ", header = FALSE)
head(datori)
colnames(datori) <- c("time", "col1", "col2")
time_day = substring(datori$time, 1, 10)
num_networks <- length(unique(time_day))
datori$day <- time_day
unique_days <- unique(time_day)

grlist <- c()
for(win in 1:num_networks){
  inds <- which(datori$day %in% unique_days[win])
  datwin <- datori[inds, 2:3]
  gr <- graph_from_data_frame(datwin)
  grlist[[win]] <- gr
}

jj <- 2
grt <- grlist[[jj]]
layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g1 <- ggraph(layout) +
  geom_edge_link(edge_colour = "grey66") +
  geom_node_point(col = "black", show.legend = FALSE) +
  theme_bw()  +
  xlab("") +
  ylab("") +
  ggtitle(unique_days[jj]) +
  theme(legend.position = "none")

jj <- 80
grt <- grlist[[jj]]
layout <- create_layout(grt, layout = 'igraph', algorithm = 'nicely')
g2 <- ggraph(layout) +
  geom_edge_link(edge_colour = "grey66") +
  geom_node_point(col = "black", show.legend = FALSE) +
  theme_bw()  +
  xlab("") +
  ylab("") +
  ggtitle(unique_days[jj]) +
  theme(legend.position = "none")


gridExtra::grid.arrange(g1, g2, nrow = 1)
# Figure 29(b)

