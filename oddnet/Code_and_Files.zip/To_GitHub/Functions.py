#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 28 10:34:30 2023

@author: kan092
"""
import numpy as np

# networkx version
# nx.__version__  
# Out[114]: '2.8.4'

# tensorflow version
# tf.__version__
# Out[117]: '2.7.0'

# sklearn.__version__
# Out[120]: '1.1.1'

# numpy.__version__
# Out[122]: '1.23.5'

# statsforecast.__version__
# Out[124]: '1.5.0'

# pandas.__version__
# Out[126]: '2.0.2'

# shap.__version__
# Out[131]: '0.41.0'

# aeon.__version__
# Out[136]: '0.3.0'

# igraph.__version__
# Out[140]: '0.10.4'

def train_LSTM2(dataset):
    import numpy as np
    import tensorflow as tf
    from tensorflow.keras.models import Sequential
    from tensorflow.keras.layers import Dense
    from tensorflow.keras.layers import LSTM
    from sklearn.preprocessing import MinMaxScaler
    from sklearn.metrics import mean_squared_error
    
    tf.random.set_seed(7)
    
    # normalize the dataset
    scaler = MinMaxScaler(feature_range=(0, 1))
    dataset = scaler.fit_transform(dataset)
    
    
    trainX = dataset[:-1, :]
    trainY = dataset[1:, :]
    
    # reshape input to be [samples, time steps, features]
    trainX = np.reshape(trainX, (trainX.shape[0], 1, trainX.shape[1]))
    
    # create and fit the LSTM network
    model = Sequential()
    model.add(LSTM(trainX.shape[2], input_shape=(trainX.shape[1], trainX.shape[2])))
    model.add(Dense(trainX.shape[2]))
    model.compile(loss='mean_squared_error', optimizer='adam')
    model.fit(trainX, trainY, epochs=100, batch_size=1, verbose=2)
    
    # make predictions
    trainPredict = model.predict(trainX)
    
    # invert predictions
    trainPredict = scaler.inverse_transform(trainPredict)
    trainY = scaler.inverse_transform(trainY)
    
    trainScore = np.sqrt(mean_squared_error(trainY, trainPredict))
    print('Train Score: %.2f RMSE' % (trainScore))
    
    residuals = trainY - trainPredict
    row_add = np.array([0]*residuals.shape[1])
    residuals2 = np.r_[[row_add], residuals]

    return residuals2

def create_dataset(dataset,look_back=1):

	dataX, dataY = [], []
	for i in range(len(dataset)-look_back-1):
		a = dataset[i:(i+look_back), 0]
		dataX.append(a)
		dataY.append(dataset[i + look_back, 0])
	return np.array(dataX), np.array(dataY)


def train_LSTM(dataset,lookback):
    import numpy as np
    import tensorflow as tf
    from tensorflow.keras.models import Sequential
    from tensorflow.keras.layers import Dense
    from tensorflow.keras.layers import LSTM
    from sklearn.preprocessing import MinMaxScaler
    from sklearn.metrics import mean_squared_error
    
    tf.random.set_seed(7)
    
    # normalize the dataset
    scaler = MinMaxScaler(feature_range=(0, 1))
    dataset = scaler.fit_transform(dataset)
    
    look_back = 1
    trainX, trainY = create_dataset(dataset, look_back)
    
    # reshape input to be [samples, time steps, features]
    trainX = np.reshape(trainX, (trainX.shape[0], 1, trainX.shape[1]))
    
    # create and fit the LSTM network
    model = Sequential()
    model.add(LSTM(4, input_shape=(1, look_back)))
    model.add(Dense(1))
    model.compile(loss='mean_squared_error', optimizer='adam')
    model.fit(trainX, trainY, epochs=100, batch_size=1, verbose=2)
    
    # make predictions
    trainPredict = model.predict(trainX)
    
    # invert predictions
    trainPredict = scaler.inverse_transform(trainPredict)
    trainY = scaler.inverse_transform([trainY])
    
    trainScore = np.sqrt(mean_squared_error(trainY[0], trainPredict[:,0]))
    print('Train Score: %.2f RMSE' % (trainScore))
    
    aa = trainY[0].reshape(len(trainY[0]), 1)
    bb = trainPredict
    out = np.concatenate((aa,bb), axis = 1)
    
    return out


def LSTM_multi(dataset, lookback):
    
    cols= dataset.shape[1]
    residuals = 0
    for ii in range(cols):
        dat = dataset[:,ii].reshape(dataset.shape[0], 1)
        out = train_LSTM(dat, lookback)
        res = out[:,1] - out[:,0]
        res = res.reshape(len(res), 1)
        if ii == 0:
            residuals = res
        else:
            residuals = np.concatenate((residuals, res), axis = 1)
    return residuals

    
def timeseries_forecast(df, frequency='M', seasonal_length=None):
    # ts is a single time series
    from statsforecast import StatsForecast
    from statsforecast.models import AutoARIMA
    import numpy as np
    
    if(seasonal_length is None):
        sf = StatsForecast(
            models = [AutoARIMA()],
            freq = frequency)
    else:
        sf = StatsForecast(
            models = [AutoARIMA(season_length = seasonal_length)],
            freq = frequency)
        
    sf.fit(df) 
    preds = sf.forecast(h=2, fitted=True)
    df_fitted = sf.forecast_fitted_values()
    return df_fitted
    

def multi_timeseries_residuals(dataset, frequency = 'M', seasonal_length=None):
    import pandas as pd
    import numpy as np
    
    cols= dataset.shape[1]
    dataset = np.array(dataset)
    ds = range(dataset.shape[0])
    residuals = 0
    for ii in range(cols):
        y = dataset[:,ii]
        dat = {'unique_id': ['id']*dataset.shape[0],
               'ds': ds,
               'y': y}
        df = pd.DataFrame(dat)
        tsf = timeseries_forecast(df, frequency=frequency, seasonal_length=seasonal_length )
        res = tsf.iloc[:,1] - tsf.iloc[:,2] 
        if(ii==0):
            residuals = res
        else:
            residuals = pd.concat([residuals, res], axis = 1)
    return residuals



def embed_graphs(graphs, fast, method='graph2vec', dim = 5): 
    
    from sklearn.decomposition import PCA
    from sklearn.preprocessing import StandardScaler
    from karateclub.graph_embedding import Graph2Vec, FGSD, GL2Vec
    import Functions as fn
    
    if method == "gl2vec":
        model = GL2Vec(dimensions = dim)
        model.fit(graphs)
        embed = model.get_embedding()
    elif method == "fgsd":
        model = FGSD(hist_bins = dim)
        model.fit(graphs)
        embed = model.get_embedding()
    elif method == 'graph2vec':
        model = Graph2Vec(dimensions = dim)
        model.fit(graphs)
        embed = model.get_embedding()
    elif method =='features':
        embed = fn.graph_features(graphs, fast)
        # feat_norm = StandardScaler().fit_transform(feat) 
        # pca_feat = PCA(n_components=dim)
        # embed = pca_feat.fit_transform(feat_norm)
    return embed


def anomaly_detection(res, method="iso", threshold = 98, feat_names = None, doshap = False):
    # method can take the values iso, lof, dbscan
    # output can be scores or preds
    # scores will give the anomaly scores
    # preds will give the single output
    from sklearn.preprocessing import MinMaxScaler
    from sklearn.ensemble import IsolationForest
    from sklearn.neighbors import LocalOutlierFactor
    import numpy as np
    from sklearn.cluster import DBSCAN
    from sklearn.neighbors import NearestNeighbors
    from sklearn.svm import OneClassSVM
    import pandas as pd
    import tensorflow as tf
    from tensorflow.keras import layers, losses
    import shap
    from aeon.annotation.stray import STRAY
    import math
    
    out_prop = (100 - threshold)/100
    kk = math.ceil(res.shape[0]/20)
    
    # scale residuals 
    scaler = MinMaxScaler()
    res = scaler.fit_transform(res)
     
    if(method == "iso"):
        model=IsolationForest(random_state=0, contamination=out_prop)
        model.fit(res)
        scores = model.decision_function(res) 
        preds = model.predict(res)
        
        if(doshap):
            # Fits the explainer
            explainer = shap.Explainer(model.predict, res, feature_names = feat_names, seed = 2023)
            # Calculates the SHAP values - It takes some time
            shap_values = explainer(res)        
        else:
            shap_values = None
    elif(method =="lof"):
        clf = LocalOutlierFactor(n_neighbors=kk, contamination=out_prop)
        preds = clf.fit_predict(res)
        scores = clf.negative_outlier_factor_
        
        if(doshap):
            # Fits the explainer
            explainer = shap.Explainer(clf.fit_predict, res, feature_names = feat_names, seed = 2023)
            # Calculates the SHAP values - It takes some time
            shap_values = explainer(res)    
        else:
            shap_values = None
    elif(method =="dbscan"):
        dbscan = DBSCAN(eps = 1, min_samples = 3)
        # dbscan doesn't give anomaly scores 
        preds = dbscan.fit_predict(res)
        scores = preds
        
        if(doshap):
            # Fits the explainer
            explainer = shap.Explainer(dbscan.fit_predict, res, feature_names = feat_names, seed = 2023)
            # Calculates the SHAP values - It takes some time
            shap_values = explainer(res)    
        else:
            shap_values = None
    elif(method == 'knn'):
        nbrs = NearestNeighbors(n_neighbors=kk)
        nbrs.fit(res)
        dist, inds = nbrs.kneighbors(res)
        dist = pd.DataFrame(dist)
        dist_mean = dist.mean(axis = 1)
        dist_mean = np.array(dist_mean)
        scores = -1*dist_mean
        anom_threshold = np.percentile(dist_mean, threshold)
        preds = [1 if i < anom_threshold else -1 for i in dist_mean]
        preds = np.array(preds)
        shap_values = None
    elif(method == 'ocsvm'):
        one_class_svm = OneClassSVM(nu=out_prop, kernel = 'rbf', gamma = 'auto').fit(res)
        preds = one_class_svm.predict(res)
        scores = one_class_svm.score_samples(res)
        
        if(doshap):
            # Fits the explainer
            explainer = shap.Explainer(one_class_svm.predict, res, feature_names = feat_names, seed = 2023)
            # Calculates the SHAP values - It takes some time
            shap_values = explainer(res)  
        else:
            shap_values = None
    elif(method =='autoen'):
        input_shp = res.shape[1]
        input = tf.keras.layers.Input(shape=(input_shp,))
        # Encoder layers
        encoder = tf.keras.Sequential([
          layers.Dense(int(input_shp*3/4), activation='relu'),
          layers.Dense(int(input_shp/2), activation='relu')])(input)
        # Decoder layers
        decoder = tf.keras.Sequential([
              layers.Dense(int(input_shp*3/4), activation="relu"),
              layers.Dense(input_shp, activation="sigmoid")])(encoder)
        # Create the autoencoder
        autoencoder = tf.keras.Model(inputs=input, outputs=decoder)
       
        # Predict
        prediction = autoencoder.predict(res)
        prediction_loss = tf.keras.losses.mae(prediction, res)
        loss_threshold = np.percentile(prediction_loss, threshold)

        # Check the model performance at 2% threshold
        preds = [1 if i < loss_threshold else -1 for i in prediction_loss]
        preds = np.array(preds)
        scores = -1*prediction_loss
        
        if(doshap):
            # Fits the explainer
            explainer = shap.Explainer(autoencoder.predict, res, feature_names = feat_names, seed = 2023)
            # Calculates the SHAP values - It takes some time
            shap_values = explainer(res)  
        else:
            shap_values = None
    elif(method == 'stray'):
        model = STRAY(alpha = 0.1, k=kk)
        y = model.fit_transform(res)
        scores = -1*model.score_
        preds = [1]*res.shape[0]
        preds = np.array(preds)
        preds[y == True] = -1
        if(doshap):
            explainer = shap.Explainer(model.fit_transform, res, feature_names = feat_names, seed = 2023)
            shap_values = explainer(res)
        else:
            shap_values = None
        
    return preds, scores, shap_values


def triangles(g):
    import igraph as ig
    
    cliques = g.cliques(min=3, max=3)
    result = [0] * g.vcount()
    for i, j, k in cliques:
        result[i] += 1
        result[j] += 1
        result[k] += 1
    return result



def graph_features(graphs, fast):
    
    import Functions as fn
    import igraph as ig
    import pandas as pd
    
    
    num_graphs = len(graphs)
    features = np.zeros((num_graphs,20))
    for i in range(num_graphs):
        gr = graphs[i]
        gr = ig.Graph.from_networkx(gr)
        features[i,:] = fn.get_graph_features(gr, fast)
    featuresdf = pd.DataFrame(features)
    featuresdf.columns = ['num_nodes', 'triangles', 'deg', 'edges', 'density', 'clust_coef', 'assort', 
           'diameter', 'isolates', 'connectivity', 'efficiency', 'clust_size', 'num_clust', 
           'closeness', 'close_overpoint8', 'between', 'pagerank', 'cores', 'hubscore',
           'authority_score']
    return featuresdf

    

def get_graph_features(g, fast):
    
    import igraph as ig
    import numpy as np
    import Functions as fn
    from statistics import mean 
     
    
    # Number of vertices
    num_nodes = g.vcount()
    
    # Traingles
    tr = fn.triangles(g)
    triangles_99 = np.percentile(tr, 99)
    
    # Degree
    deg = g.degree()
    deg_99 = np.percentile(deg, 99)
    
    # Number of edges
    edges = g.ecount()
    
    # Density
    density = g.density()
    
    # Clustering coefficient
    clust_coef = g.transitivity_undirected()
    
    # Assortativity
    assort = g.assortativity_degree()
    
    ## MEAN DISTANCE NOT DONE!
    
    # Diameter
    diameter = len(g.get_diameter())
    
    # Isolates
    isolates = deg.count(0)/len(deg)
    
    # Connectivity
    if (fast == True):
        connectivity = 0 
    else:
        connectivity = g.vertex_connectivity()
          
    # Efficiency
    efficiency = mean(g.harmonic_centrality())    
    
    # Number of clusters and cluster size --- THIS IS NOT FINISHED!!!
    vdendro = ig.Graph.community_fastgreedy(g)
    clust = vdendro.as_clustering()
    clust_el = [0]*len(clust)
    for i in range(len(clust)):
        clust_el[i] = len(clust[i])
    clust_size_99 = np.percentile(clust_el, 99)
    num_clust = len(clust)
    
    # Closeness 
    close_obj = g.closeness()
    closeness_99 = np.percentile(close_obj, 99)
    close_overpoint8 = len([i for i in close_obj if i > 0.8])/len(close_obj)
    
    # Betweenness
    between_obj = ig.Graph.betweenness(g)
    between_99 = np.percentile(between_obj, 99)
    
    # Pagerank
    pagerank = ig.Graph.pagerank(g)
    pagerank_99 = np.percentile(pagerank, 99)

    # Cores
    cores = ig.Graph.coreness(g)
    cores_99 = np.percentile(cores, 99)

    # Hubs
    hubs = ig.Graph.hub_score(g, return_eigenvalue=True)
    hubscore = hubs[1]
    
    # Authority score
    authority = ig.Graph.authority_score(g)
    authority_score = np.percentile(authority, 99)
    
    out = [num_nodes, triangles_99, deg_99, edges, density, clust_coef, assort, 
           diameter, isolates, connectivity, efficiency, clust_size_99, num_clust, 
           closeness_99, close_overpoint8, between_99, pagerank_99, cores_99, hubscore,
           authority_score]
    out = np.array(out)
    out[np.isnan(out)] = 0
    return out


def graph_anomaly(graphs, 
                  embedding_method=1, 
                  embed_dim=5, 
                  temporal_method=1,
                  seasonal_length = None,
                  anomaly_method=1,
                  threshold = 98,
                  doshap = False, 
                  fast = False):
    import igraph as ig
    import numpy as np
    import Functions as fn
    
    # GRAPH EMBEDDING
    if(embedding_method == 1):
        embeded = embed_graphs(graphs, method='gl2vec', dim=embed_dim, fast = fast)
        feat_names = None
    elif(embedding_method ==2):
        embeded = embed_graphs(graphs, method='fgsd', dim=embed_dim, fast = fast)
        feat_names = None
    elif(embedding_method ==3):
        embeded = embed_graphs(graphs, method='graph2vec', dim=embed_dim, fast = fast)
        feat_names = None
    elif(embedding_method ==4):
        embeded = embed_graphs(graphs, method='features', dim=embed_dim, fast = fast)
        feat_names = ['num_nodes', 'triangles', 'deg', 'edges', 'density', 'clust_coef', 'assort', 
               'diameter', 'isolates', 'connectivity', 'efficiency', 'clust_size', 'num_clust', 
               'closeness', 'close_overpoint8', 'between', 'pagerank', 'cores', 'hubscore',
               'authority_score']
    else:
        print('Invalid input parameter value. Parameter embedding_method can take values from 1 to 4.')
        return
    
        
    # TIME DEPENDENCE
    if temporal_method ==1:
        # residuals = fn.LSTM_multi(embeded, lookback=1)
        residuals = fn.train_LSTM2(embeded)
    elif temporal_method ==2:
        residuals = fn.multi_timeseries_residuals(embeded, seasonal_length = seasonal_length)        
    else:
        print('Invalid input for temporal_method. It can take values 1 or 2.')
        return      
    
  
    
    # ANOMALY DETECTION 
    if(anomaly_method == 1):
        anom, scores, shapval = anomaly_detection(residuals, method ='iso', threshold= threshold,feat_names = feat_names, doshap = doshap)
    elif(anomaly_method == 2):
        anom, scores, shapval = anomaly_detection(residuals, method ='lof', threshold = threshold,feat_names = feat_names, doshap = doshap)
    elif(anomaly_method == 3):
        anom, scores, shapval = anomaly_detection(residuals, method ='dbscan', threshold = threshold,feat_names = feat_names, doshap = doshap) 
    elif(anomaly_method == 4):
        anom, scores, shapval = anomaly_detection(residuals, method ='knn', threshold = threshold,feat_names = feat_names, doshap = doshap) 
    elif(anomaly_method == 5):
        anom, scores, shapval = anomaly_detection(residuals, method ='ocsvm', threshold= threshold,feat_names = feat_names, doshap = doshap) 
    elif(anomaly_method  == 6):
        anom, scores, shapval = anomaly_detection(residuals, method ='autoen', threshold= threshold,feat_names = feat_names, doshap = doshap) 
    elif(anomaly_method  == 7):
        anom, scores, shapval = anomaly_detection(residuals, method ='stray', threshold= threshold,feat_names = feat_names, doshap = doshap)         
    else:
        print('Invalid input for anomaly_method. It can take values from 1 to 6.')
        return        
    return anom, scores, shapval 










































































    