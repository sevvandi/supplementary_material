#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul 25 15:30:09 2023

@author: kan092
"""
# Look at Analysis_01.py Task 6 
# -----------------------------------------------------------------------------
# TASK  01: SENATE VOTING DATASET
# TASK  02: UCI MESSAGE DATASET
# TASK  03: CANADIAN VOTING  DATASET
# TASK  04: US PRESIDENTIAL BLOGS
# TASK  05: PHYSICS CITATIONS DATASET
# TASK  06: TWITTER DATASET
# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
# TASK  01: SENATE VOTING DATASET
# -----------------------------------------------------------------------------

# seaborn version
# sn.__version__
# Out[149]: '0.11.2'

import Functions as fn
import numpy as np
import pickle as pkl
from matplotlib import pyplot as plt
import networkx as nx
import shap
import seaborn as sn
import random


with open("SenateVoting.pkl", "rb") as fp:   
    snvote = pkl.load(fp)

senatorvote = [nx.from_numpy_matrix(snvote[i]) for i in range(0,len(snvote)) ]

#%%

ii = 0
anom_scores = np.zeros([74,56])
method_details = np.zeros([56,3])
for emb_method in range(1,5):
    for temp_method in range(1,3):
        for anom_method in range(1,8):
            anom, scores, shapley  = fn.graph_anomaly(senatorvote, 
                                                     embedding_method = emb_method,
                                                     embed_dim=20, 
                                                     temporal_method = temp_method,
                                                     anomaly_method = anom_method,
                                                     doshap = False)
            anom_scores[:,ii] = scores
            method_details[ii,:] = [emb_method, temp_method, anom_method]
            ii = ii + 1

np.savetxt("Senator_Voting_Anomaly_Scores.csv", anom_scores, delimiter=",")
np.savetxt("Senator_Voting_Different_Methods.csv", method_details, delimiter=",")



# The most anomalous networok 100th Congress
# The shap values of Networks 60: 100th Congresses
anom, scores, shapley = fn.graph_anomaly(senatorvote, 
                                         embedding_method=4, 
                                         embed_dim=20, 
                                         temporal_method=1,
                                         anomaly_method=1, 
                                         doshap = True,
                                         threshold = 95)
shapley.base_values
# 0.89189189,

# The following figures are in Figure 19
# The index starts at the 40th Congress. 
anom
plt.plot(scores)
np.where(anom == -1)
shap.plots.bar(shapley[60])
shap.plots.bar(shapley[60],  show=False)
plt.savefig('Us_Senate_Shap_100_Congress.pdf', dpi = 500,  bbox_inches='tight')
# Figure 19(a)

# The second most anomalous network 71: 111th Congress 
shap.plots.bar(shapley[71])
shap.plots.bar(shapley[71], show=False)
plt.savefig('Us_Senate_Shap_111_Congress.pdf', dpi = 500,  bbox_inches='tight')
# Figure 19(b)


shap.plots.bar(shapley)
shap.plots.bar(shapley, show=False)
plt.savefig('Us_Senate_Shap_Mean.pdf', dpi = 500,  bbox_inches='tight')
# Figure 19(d)



anom, scores, shapley = fn.graph_anomaly(senatorvote, 
                                         embedding_method=4, 
                                         embed_dim=20, 
                                         temporal_method=1,
                                         anomaly_method=2, 
                                         doshap = True,
                                         threshold = 95)

np.where(anom == -1)
shap.plots.bar(shapley[67])
shap.plots.bar(shapley[67], show=False)
plt.savefig('Us_Senate_Shap_107_Congress.pdf', dpi = 500,  bbox_inches='tight')
# Figure 19(c) Using LOF instead with anomaly_method = 2

# -----------------------------------------------------------------------------
# TASK  02: UCI MESSAGE DATASET
# -----------------------------------------------------------------------------


# UCI Message 
with open("UCIMessage.pkl", "rb") as fp:   
    ucim = pkl.load(fp)

ucimessage = [nx.from_numpy_matrix(ucim[i]) for i in range(0,len(ucim)) ]


ii = 0
anom_scores = np.zeros([len(ucimessage),56])
method_details = np.zeros([56,3])
for emb_method in range(1,5):
    for temp_method in range(1,3):
        for anom_method in range(1,8):
            anom, scores, shapley  = fn.graph_anomaly(ucimessage, 
                                                     embedding_method = emb_method,
                                                     embed_dim=20, 
                                                     temporal_method = temp_method,
                                                     anomaly_method = anom_method,
                                                     doshap = False,
                                                     fast = False)
            anom_scores[:,ii] = scores
            method_details[ii,:] = [emb_method, temp_method, anom_method]
            ii = ii + 1
            
np.savetxt("UCI_Message_Anomaly_Scores.csv", anom_scores, delimiter=",")
np.savetxt("UCI_Message_Different_Methods.csv", method_details, delimiter=",")
            

#%%
anom, scores, shapley = fn.graph_anomaly(ucimessage, 
                                         embedding_method=4, 
                                         embed_dim=20, 
                                         temporal_method=1,
                                         anomaly_method=2, 
                                         doshap = True,
                                         threshold = 95)

shapley.base_values
anom
plt.plot(scores)
np.where(anom == -1)


# These are for Figure 22
jj = 24
shap.plots.bar(shapley[jj])
shapley.base_values[jj]

shap.plots.bar(shapley)

shap.plots.bar(shapley[jj], show=False)
plt.savefig('UCI_Message_Shap_25_May_8_Day.pdf', dpi = 500,  bbox_inches='tight')
# Figure 22(a) Day 25 = index 24

jj = 89
shap.plots.bar(shapley[jj])
shapley.base_values[jj]
# Figure 22(b) 

shap.plots.bar(shapley[jj], show=False)
plt.savefig('UCI_Message_Shap_90_July_12_Day.pdf', dpi = 500,  bbox_inches='tight')


shap.plots.bar(shapley)


# 1    25 2004-05-08            26
# 2    90 2004-07-12            25
# 3    41 2004-05-24            19
# 4     4 2004-04-15            11



# -----------------------------------------------------------------------------
# TASK  03: CANADIAN VOTING  DATASET
# -----------------------------------------------------------------------------

import Functions as fn
import numpy as np
import pickle as pkl
from matplotlib import pyplot as plt
import networkx as nx
import shap
import seaborn as sn
import random


# Canadian Voting
with open("CanadianVoting.pkl", "rb") as fp:   # Unpickling
    canada = pkl.load(fp)

canadavotes = [nx.from_numpy_matrix(canada[i]) for i in range(0,len(canada)) ]


ii = 0
anom_scores = np.zeros([len(canadavotes),56])
method_details = np.zeros([56,3])
for emb_method in range(1,5):
    for temp_method in range(1,3):
        for anom_method in range(1,8):
            print('embedding', emb_method)
            print('temporal', temp_method)
            print('anomaly', anom_method)
            anom, scores, shapley  = fn.graph_anomaly(canadavotes, 
                                                     embedding_method = emb_method,
                                                     embed_dim=20, 
                                                     temporal_method = temp_method,
                                                     anomaly_method = anom_method,
                                                     doshap = False,
                                                     fast = False)
            anom_scores[:,ii] = scores
            method_details[ii,:] = [emb_method, temp_method, anom_method]
            ii = ii + 1
            
np.savetxt("Canadian_Voting_Anomaly_Scores.csv", anom_scores, delimiter=",")
np.savetxt("Canadian_Voting_Different_Methods.csv", method_details, delimiter=",")
            


#%%
emb_method = 4
temp_method = 1
anom_method = 1
anom, scores, shapley  = fn.graph_anomaly(canadavotes, 
                                          embedding_method = emb_method,
                                          embed_dim=20, 
                                          temporal_method = temp_method,
                                          anomaly_method = anom_method,
                                          doshap = True,
                                          threshold = 90,
                                          fast = False)


# Figure 24
np.where(anom == -1)
shapley.base_values
shap.plots.bar(shapley[9]) # Corresponding to entry 10
# Figure 24 (c)
shap.plots.bar(shapley[9], show=False)
plt.savefig('Canadian_Voting_Shap_10_2015.pdf', dpi = 500,  bbox_inches='tight')


emb_method = 4
temp_method = 2
anom_method = 1
anom, scores, shapley  = fn.graph_anomaly(canadavotes, 
                                          embedding_method = emb_method,
                                          embed_dim=20, 
                                          temporal_method = temp_method,
                                          anomaly_method = anom_method,
                                          doshap = True,
                                          threshold = 90)


np.where(anom == -1)
shapley.base_values

shap.plots.bar(shapley[5]) # Corresponding to entry 10
# Figure 24 (b)
shap.plots.bar(shapley[5], show=False)
plt.savefig('Canadian_Voting_Shap_6_2011.pdf', dpi = 500,  bbox_inches='tight')




# -----------------------------------------------------------------------------
# TASK  04: US PRESIDENTIAL BLOGS
# -----------------------------------------------------------------------------


with open("USPresidentsBlogs.pkl", "rb") as fp:   
    blogs = pkl.load(fp)

presblogs = [nx.from_numpy_matrix(blogs[i]) for i in range(0,len(blogs)) ]


ii = 0
anom_scores = np.zeros([len(presblogs),56])
method_details = np.zeros([56,3])
for emb_method in range(1,5):
    for temp_method in range(1,3):
        for anom_method in range(1,8):
            print('embedding', emb_method)
            print('temporal', temp_method)
            print('anomaly', anom_method)
            anom, scores, shapley  = fn.graph_anomaly(presblogs, 
                                                     embedding_method = emb_method,
                                                     embed_dim=20, 
                                                     temporal_method = temp_method,
                                                     anomaly_method = anom_method,
                                                     doshap = False,
                                                     fast = False)
            anom_scores[:,ii] = scores
            method_details[ii,:] = [emb_method, temp_method, anom_method]
            ii = ii + 1

np.savetxt("US_Presidential_Blogs_Anomaly_Scores.csv", anom_scores, delimiter=",")
np.savetxt("US_Presidential_Blogs_Different_Methods.csv", method_details, delimiter=",")



#%%
emb_method = 4
temp_method = 1
anom_method = 1
anom, scores, shapley  = fn.graph_anomaly(presblogs, 
                                          embedding_method = emb_method,
                                          embed_dim=20, 
                                          temporal_method = temp_method,
                                          anomaly_method = anom_method,
                                          doshap = True,
                                          threshold = 95)



np.where(anom == -1)
shapley.base_values
shap.plots.bar(shapley[245])
# Figure 26(b)
shap.plots.bar(shapley[245], show=False)
plt.savefig('US_Blogposts_2004_09_21.pdf', dpi = 500,  bbox_inches='tight')


# Dates anomaly_times
# 453 2004-11-12            27
# 246 2004-09-21            20
# 458 2004-11-13            20
# 17  2004-07-26            15





# -----------------------------------------------------------------------------
# TASK  05: PHYSICS CITATIONS DATASET
# -----------------------------------------------------------------------------

import pandas as pd
from itertools import chain

dattimes = pd.read_csv('Data_Input/cit-HepPh/cit-HepPh-dates_2.csv')
dat = pd.read_csv('Data_Input/cit-HepPh/Cit-HepPh-Dynamic_char_fixed_1.csv')

dat2 = dat.iloc[0:10,:]



# Sort by date
dat['Date'] = pd.to_datetime(dat['Date']) 
dat.sort_values(by='Date', inplace = True)

dat['Month'] = dat['Date'].dt.to_period('M')
months = dat.iloc[:,3].unique()
dat = dat.reset_index(drop=True)


netlist = []
for i in range(len(months)):
   dat_m = dat[dat['Month'] == months[i]]
   net = nx.from_pandas_edgelist(dat_m, 
                                     source='FromNodeId', 
                                     target='ToNodeId') 
   # To get the node indexing right
   numeric_indices = [index for index in range(net.number_of_nodes())]
   node_indices = sorted([node for node in net.nodes()])
   mapping = dict(zip(node_indices, numeric_indices))
   net = nx.relabel_nodes(net, mapping)
   netlist.append(net)
              
              
ii = 0
anom_scores = np.zeros([len(netlist),56])
method_details = np.zeros([56,3])
for emb_method in range(1,5):
    for temp_method in range(1,3):
        for anom_method in range(1,8):
            method_details[ii,:] = [emb_method, temp_method, anom_method]
            ii = ii + 1


# FSGD doesn't work for this example
# SVD decomposition gives an error

# for ii in range(27,28):
#     emb_method = method_details[ii,0]
#     temp_method = method_details[ii,1]
#     anom_method = method_details[ii,2]
#     print('ii', ii)
#     print('embedding', emb_method)
#     print('temporal', temp_method)
#     print('anomaly', anom_method)
#     anom, scores, shapley  = fn.graph_anomaly(netlist, 
#                                               embedding_method = emb_method,
#                                               embed_dim=20, 
#                                               temporal_method = temp_method,
#                                               anomaly_method = anom_method,
#                                               doshap = False,
#                                               fast = True)
#     anom_scores[:,ii] = scores



concatenated = chain(range(14),range(28,56))
for ii in concatenated:
    emb_method = method_details[ii,0]
    temp_method = method_details[ii,1]
    anom_method = method_details[ii,2]
    print('ii', ii)
    print('embedding', emb_method)
    print('temporal', temp_method)
    print('anomaly', anom_method)
    anom, scores, shapley  = fn.graph_anomaly(netlist, 
                                              embedding_method = emb_method,
                                              embed_dim=20, 
                                              temporal_method = temp_method,
                                              anomaly_method = anom_method,
                                              doshap = False,
                                              fast = True)
    anom_scores[:,ii] = scores

np.savetxt("Physics_Citations_Anomaly_Scores.csv", anom_scores, delimiter=",")
np.savetxt("Physics_Citations_Different_Methods.csv", method_details, delimiter=",")

monthsdf = pd.DataFrame(months)
monthsdf.to_csv("Physics_Citations_Months.csv")

#%% 

emb_method = 4
temp_method = 1
anom_method = 1
anom, scores, shapley  = fn.graph_anomaly(netlist, 
                                         embedding_method = emb_method,
                                         embed_dim=20, 
                                         temporal_method = temp_method,
                                         anomaly_method = anom_method,
                                         doshap = True,
                                         fast = True)

np.where(anom == -1)
shap.plots.bar(shapley[113])
# Figure 28 (b)
shap.plots.bar(shapley[113], show=False)
plt.savefig('Physics_Citations_2001-10.pdf', dpi = 500,  bbox_inches='tight')


# > dat5[inds ,]
# Month anomaly_times
# 114 2001-10-01             6
# 58  1997-02-01             5
# 59  1997-03-01             5
# 118 2002-02-01             5
# 62  1997-06-01             4
# 78  1998-10-01             4
# 116 2001-12-01             4


# -----------------------------------------------------------------------------
# TASK  06: TWITTER DATASET
# -----------------------------------------------------------------------------
#%%
# Dataset is available at this website. 
# It is 125 MB and cannot be stored on GitHub
# Please download this file and update the filename in the next line
# https://odds.cs.stonybrook.edu/twittersecurity-dataset/
filename = '/Users/kan092/Library/CloudStorage/OneDrive-CSIRO/Documents/Research/Networks/Datasets/Twitter/Twitter_May_Aug_2014_TerrorSecurity_resolved.txt'

datf = pd.read_csv(filename, delimiter =' ', header = None)
datf.columns =['time', 'col1', 'col2']
dat1 = datf

# Sort by date
dat1['time_Trunc'] = dat1['time'].str.slice(0,10)
dat1['time_Trunc2'] = pd.to_datetime(dat1['time_Trunc'], format='%m:%d:%Y') 
dat1.sort_values(by='time_Trunc2', inplace = True)


dates = dat1.iloc[:,4].unique()


netlist = []
for i in range(len(dates)):
   dat_m = dat1[dat1['time_Trunc2'] == dates[i]]
   net = nx.from_pandas_edgelist(dat_m, 
                                 source='col1', 
                                 target='col2') 
   # To get the node indexing right
   numeric_indices = [index for index in range(net.number_of_nodes())]
   node_indices = sorted([node for node in net.nodes()])
   mapping = dict(zip(node_indices, numeric_indices))
   net = nx.relabel_nodes(net, mapping)
   netlist.append(net)


#nx.draw(netlist[2])


ii = 0
anom_scores = np.zeros([len(netlist),56])
method_details = np.zeros([56,3])
for emb_method in range(1,5):
    for temp_method in range(1,3):
        for anom_method in range(1,8):
            method_details[ii,:] = [emb_method, temp_method, anom_method]
            ii = ii + 1


anom_scores = np.zeros([len(netlist),56])
# FSGD doesn't work for this as well
concatenated = chain(range(14),range(28,56))
for ii in concatenated:
    emb_method = method_details[ii,0]
    temp_method = method_details[ii,1]
    anom_method = method_details[ii,2]
    print('ii', ii)
    print('embedding', emb_method)
    print('temporal', temp_method)
    print('anomaly', anom_method)
    anom, scores, shapley  = fn.graph_anomaly(netlist, 
                                              embedding_method = emb_method,
                                              embed_dim=20, 
                                              temporal_method = temp_method,
                                              anomaly_method = anom_method,
                                              threshold = 95,
                                              doshap = False,
                                              fast = True)
    anom_scores[:,ii] = scores

np.savetxt("Twitter_Anomaly_Scores.csv", anom_scores, delimiter=",")
np.savetxt("Twitter_Different_Methods.csv", method_details, delimiter=",")

datesdf = pd.DataFrame(dates)
datesdf.to_csv("Twitter_Dates.csv")



#%% 

emb_method = 4
temp_method = 1
anom_method = 2
anom, scores, shapley  = fn.graph_anomaly(netlist, 
                                         embedding_method = emb_method,
                                         embed_dim=20, 
                                         temporal_method = temp_method,
                                         anomaly_method = anom_method,
                                         threshold = 95,
                                         doshap = True,
                                         fast = True)

np.where(anom == -1)
shap.plots.bar(shapley[3])
# Figure 30(a)
shap.plots.bar(shapley[3], show=False)
plt.savefig('Twitter_May_13_2014.pdf', dpi = 500,  bbox_inches='tight')


shap.plots.bar(shapley[79])
# Figure 30(b)
shap.plots.bar(shapley[79], show=False)
plt.savefig('Twitter_August_1_2014.pdf', dpi = 500,  bbox_inches='tight')


# > dat4[inds ,]
#          Date anomaly_times
# 2  2014-05-12            24
# 1  2014-05-02            20
# 3  2014-05-13            18
# 80 2014-08-01            13
# 7  2014-05-20             5
# 8  2014-05-21             5
# 13 2014-05-26             5




























