# -------------------------------------------------------------------------------
# TASK  01: ERDOS-RENYI GRAPHS USING FRAMEWORK DIFFERENT METHODS
# TASK  02: BARABASI GRAPHS USING FRAMEWORK DIFFERENT METHODS
# TASK  03: WATTS STROGATZ GRAPHS USING FRAMEWORK DIFFERENT METHODS
# -------------------------------------------------------------------------------

# > sessionInfo()
# R version 4.2.1 (2022-06-23)
# Platform: x86_64-apple-darwin17.0 (64-bit)
# Running under: macOS Ventura 13.4.1
#
# Matrix products: default
# LAPACK: /Library/Frameworks/R.framework/Versions/4.2/Resources/lib/libRlapack.dylib
#
# locale:
#   [1] en_US.UTF-8/en_US.UTF-8/en_US.UTF-8/C/en_US.UTF-8/en_US.UTF-8
#
# attached base packages:
#   [1] stats     graphics  grDevices utils     datasets  methods   base
#
# other attached packages:
#   [1] forcats_0.5.1   stringr_1.5.0   dplyr_1.1.2     purrr_1.0.1     readr_2.1.2     tidyr_1.3.0
# [7] tibble_3.2.1    tidyverse_1.3.2 ggplot2_3.4.0
#
# loaded via a namespace (and not attached):
#   [1] tidyselect_1.2.0    haven_2.5.0         gargle_1.2.0        pcaPP_2.0-2
# [5] colorspace_2.0-3    vctrs_0.6.2         generics_0.1.3      utf8_1.2.2
# [9] rlang_1.1.1         pillar_1.9.0        glue_1.6.2          withr_2.5.0
# [13] DBI_1.1.3           dbplyr_2.2.1        modelr_0.1.8        readxl_1.4.0
# [17] lifecycle_1.0.3     munsell_0.5.0       gtable_0.3.0        cellranger_1.1.0
# [21] rvest_1.0.2         mvtnorm_1.1-3       labeling_0.4.2      tzdb_0.3.0
# [25] fansi_1.0.3         broom_1.0.0         backports_1.4.1     scales_1.2.0
# [29] googlesheets4_1.0.1 jsonlite_1.8.0      farver_2.1.1        FNN_1.1.3.1
# [33] fs_1.5.2            gridExtra_2.3       hms_1.1.1           stringi_1.7.8
# [37] grid_4.2.1          cli_3.4.1           tools_4.2.1         magrittr_2.0.3
# [41] stray_0.1.1         crayon_1.5.1        pkgconfig_2.0.3     ellipsis_0.3.2
# [45] xml2_1.3.3          reprex_2.0.1        googledrive_2.0.0   lubridate_1.8.0
# [49] assertthat_0.2.1    httr_1.4.3          rstudioapi_0.13     R6_2.5.1
# [53] igraph_1.3.4        compiler_4.2.1

# -------------------------------------------------------------------------------
# TASK  01: ERDOS-RENYI GRAPHS USING FRAMEWORK DIFFERENT METHODS
# -------------------------------------------------------------------------------
library(ggplot2)
library(tidyverse)

datori <- read.csv("Anomaly_Results_Different_Methods.csv")
head(datori)
colnames(datori) <- c("Embedding", "Temporal", "Anomaly", "AUC")
datori
dat <- datori %>%
  mutate(id = 1:dim(datori)[1]) %>%
  relocate(id, Embedding, Temporal, Anomaly, AUC)


dat_embed <- data.frame(Embedding = 1:4, Embedding_Method = c('GL2Vec', 'FGSD', 'Graph2Vec', 'Features'))
dat_temporal <- data.frame(Temporal = 1:2, Temporal_Method = c('LSTM', 'ARIMA'))
dat_anomaly <- data.frame(Anomaly = 1:7, Anomaly_Method = c('Isolation', 'LOF', 'DBSCAN', 'KNN', 'OCSVM', 'Autoencoder', 'stray'))


dat2 <- dat %>%
  full_join(dat_embed) %>%
  full_join(dat_temporal) %>%
  full_join(dat_anomaly)

g1 <- ggplot(dat2, aes(Embedding_Method, AUC)) +
  geom_boxplot()
g2 <- ggplot(dat2, aes(Temporal_Method, AUC)) +
  geom_boxplot()
g3 <- ggplot(dat2, aes(Anomaly_Method, AUC)) +
  geom_boxplot()
gridExtra::grid.arrange(g1, g2, g3, ncol = 2,layout_matrix = matrix(c(1,2,3,3), byrow = TRUE, ncol = 2))
# Figure 9 - the above figure

# -------------------------------------------------------------------------------
# Embedding from different methods
df_emb <- read.csv("PC_Embeddings_Ex1.csv")
colnames(df_emb) <- c("PC1", "PC2","PC1", "PC2", "PC1", "PC2","PC1", "PC2")


df_emb2 <- rbind.data.frame(cbind.data.frame(Method = 'gl2vec', df_emb[ ,1:2]),
                 cbind.data.frame(Method = 'fgsd', df_emb[ ,3:4]),
                 cbind.data.frame(Method = 'graph2vec', df_emb[ ,5:6]),
                 cbind.data.frame(Method = 'features', df_emb[ ,7:8]))


df_emb3 <- cbind.data.frame(df_emb2, label = rep(c(rep("Normal", 49), "Anomaly", rep("Normal", 50)),4))
ggplot(df_emb3, aes(x =PC1, y = PC2, color = label)) +
  geom_point() +
  facet_wrap(~Method, nrow = 1, scales = 'free')
# Figure 8 - the above figure

# -------------------------------------------------------------------------------
# TASK  02: BARABASI GRAPHS USING FRAMEWORK DIFFERENT METHODS
# -------------------------------------------------------------------------------
library(ggplot2)
library(tidyverse)

datori <- read.csv("Barabasi_Anomaly_Results_Different_Methods.csv")
head(datori)
colnames(datori) <- c("Embedding", "Temporal", "Anomaly", "AUC")
datori
dat <- datori %>%
  mutate(id = 1:dim(datori)[1]) %>%
  relocate(id, Embedding, Temporal, Anomaly, AUC)


dat_embed <- data.frame(Embedding = 1:4, Embedding_Method = c('GL2Vec', 'FGSD', 'Graph2Vec', 'Features'))
dat_temporal <- data.frame(Temporal = 1:2, Temporal_Method = c('LSTM', 'ARIMA'))
dat_anomaly <- data.frame(Anomaly = 1:7, Anomaly_Method = c('Isolation', 'LOF', 'DBSCAN', 'KNN', 'OCSVM', 'Autoencoder', 'stray'))


dat2 <- dat %>%
  full_join(dat_embed) %>%
  full_join(dat_temporal) %>%
  full_join(dat_anomaly)

g1 <- ggplot(dat2, aes(Embedding_Method, AUC)) +
  geom_boxplot()
g2 <- ggplot(dat2, aes(Temporal_Method, AUC)) +
  geom_boxplot()
g3 <- ggplot(dat2, aes(Anomaly_Method, AUC)) +
  geom_boxplot()

gridExtra::grid.arrange(g1, g2, g3, ncol = 2,layout_matrix = matrix(c(1,2,3,3), byrow = TRUE, ncol = 2))
# Figure 12

# -------------------------------------------------------------------------------
# Embedding from different methods
df_emb <- read.csv("PC_Embeddings_Ex2.csv")
colnames(df_emb) <- c("PC1", "PC2","PC1", "PC2", "PC1", "PC2","PC1", "PC2")


df_emb2 <- rbind.data.frame(cbind.data.frame(Method = 'gl2vec', df_emb[ ,1:2]),
                            cbind.data.frame(Method = 'fgsd', df_emb[ ,3:4]),
                            cbind.data.frame(Method = 'graph2vec', df_emb[ ,5:6]),
                            cbind.data.frame(Method = 'features', df_emb[ ,7:8]))


df_emb3 <- cbind.data.frame(df_emb2, label = rep(c(rep("Normal", 49), "Anomaly", rep("Normal", 50)),4))
ggplot(df_emb3, aes(x =PC1, y = PC2, color = label)) +
  geom_point() +
  facet_wrap(~Method, nrow = 1, scales = 'free')
# Figure 11

# -------------------------------------------------------------------------------
# TASK  03: WATTS STROGATZ GRAPHS USING FRAMEWORK DIFFERENT METHODS
# -------------------------------------------------------------------------------
library(ggplot2)
library(tidyverse)

datori <- read.csv("WattsStrogatz_Anomaly_Results_Different_Methods.csv")
head(datori)
colnames(datori) <- c("Embedding", "Temporal", "Anomaly", "AUC")
datori
dat <- datori %>%
  mutate(id = 1:dim(datori)[1]) %>%
  relocate(id, Embedding, Temporal, Anomaly, AUC)


dat_embed <- data.frame(Embedding = 1:4, Embedding_Method = c('GL2Vec', 'FGSD', 'Graph2Vec', 'Features'))
dat_temporal <- data.frame(Temporal = 1:2, Temporal_Method = c('LSTM', 'ARIMA'))
dat_anomaly <- data.frame(Anomaly = 1:7, Anomaly_Method = c('Isolation', 'LOF', 'DBSCAN', 'KNN', 'OCSVM', 'Autoencoder', 'stray'))


dat2 <- dat %>%
  full_join(dat_embed) %>%
  full_join(dat_temporal) %>%
  full_join(dat_anomaly)

g1 <- ggplot(dat2, aes(Embedding_Method, AUC)) +
  geom_boxplot()
g2 <- ggplot(dat2, aes(Temporal_Method, AUC)) +
  geom_boxplot()
g3 <- ggplot(dat2, aes(Anomaly_Method, AUC)) +
  geom_boxplot()

gridExtra::grid.arrange(g1, g2, g3, ncol = 2,layout_matrix = matrix(c(1,2,3,3), byrow = TRUE, ncol = 2))
# Figure 15

# -------------------------------------------------------------------------------
# Embedding from different methods
df_emb <- read.csv("PC_Embeddings_Ex3.csv")
colnames(df_emb) <- c("PC1", "PC2","PC1", "PC2", "PC1", "PC2","PC1", "PC2")


df_emb2 <- rbind.data.frame(cbind.data.frame(Method = 'gl2vec', df_emb[ ,1:2]),
                            cbind.data.frame(Method = 'fgsd', df_emb[ ,3:4]),
                            cbind.data.frame(Method = 'graph2vec', df_emb[ ,5:6]),
                            cbind.data.frame(Method = 'features', df_emb[ ,7:8]))


df_emb3 <- cbind.data.frame(df_emb2, label = rep(c(rep("Normal", 49), "Anomaly", rep("Normal", 50)),4))
ggplot(df_emb3, aes(x =PC1, y = PC2, color = label)) +
  geom_point() +
  facet_wrap(~Method, nrow = 1, scales = 'free')
# Figure 14
