#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul 18 12:54:41 2023

@author: kan092
"""
# -----------------------------------------------------------------------------
# TASK  01: ERDOS-RENYI GRAPH MODELS
# TASK  02: BARABASI GRAPH MODELS
# TASK  03: WATTS-STROGATZ SMALL WORLD MODEL
# -----------------------------------------------------------------------------


# THIS IS AN IMPORTANT NOTE - IF aeon package DOES NOT WORK PLEASE INSTALL THIS. 
# pip install threadpoolctl==3.1.0  

# -----------------------------------------------------------------------------
# TASK  01: ERDOS-RENYI GRAPH MODELS
# -----------------------------------------------------------------------------

# matplotlib.__version__
# Out[144]: '3.5.2'

import matplotlib.pyplot as plt
import Functions as fn
import networkx as nx
import random
import numpy as np
import shap
from sklearn.metrics import  roc_auc_score, roc_curve
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

random.seed(2013) 
graphs = [  nx.erdos_renyi_graph(n=100,p=0.05)  for _ in range(100)]
graph_anom = nx.erdos_renyi_graph(n=100,p=0.2) 
graphs[49] = graph_anom


ii = 0
anom_scores = np.zeros([100,56])
method_details = np.zeros([56,3])
for emb_method in range(1,5):
    for temp_method in range(1,3):
        for anom_method in range(1,8):
            anom, scores, shapley  = fn.graph_anomaly(graphs, 
                                                     embedding_method = emb_method,
                                                     embed_dim=20, 
                                                     temporal_method = temp_method,
                                                     anomaly_method = anom_method,
                                                     doshap = False)
            anom_scores[:,ii] = scores
            method_details[ii,:] = [emb_method, temp_method, anom_method]
            ii = ii + 1

plt.plot(anom_scores[:,30])
np.savetxt("Anomaly_Different_Methods.csv", anom_scores, delimiter=",")
np.savetxt("Different_Methods.csv", method_details, delimiter=",")

true_scores =[0]*100
true_scores[49] = -1

roc_scores = [0]*56
for kk in range(56):
    roc_scores[kk] = roc_auc_score(true_scores, anom_scores[:,kk])
    
method_details2 = np.zeros([56,4])
method_details2[:,0:3] = method_details
method_details2[:,3] = roc_scores
np.savetxt("Anomaly_Results_Different_Methods.csv", method_details2, delimiter=",")


# Check embeddings 

scaler = StandardScaler()
pca = PCA()

# Embedding Graph2Vec
emb1 = fn.embed_graphs(graphs, fast = True, method='gl2vec', dim = 20)
sc_emb1 = scaler.fit_transform(emb1)
pc_emb1 = pca.fit_transform(sc_emb1)
plt.plot(pc_emb1[:,0], pc_emb1[:,1], 'o')
np.where(pc_emb1[:,0] > 4)


# Embedding FGSD
emb2 = fn.embed_graphs(graphs, fast = True, method='fgsd', dim = 20)
sc_emb2 = scaler.fit_transform(emb2)
pc_emb2 = pca.fit_transform(sc_emb2)
plt.plot(pc_emb2[:,0], pc_emb2[:,1], 'o')
np.where(pc_emb2[:,1] > 8)
np.where(pc_emb2[:,0] < -3)


# Embedding graph2vec
emb3 = fn.embed_graphs(graphs, fast = True, method='graph2vec', dim = 20)
sc_emb3 = scaler.fit_transform(emb3)
pc_emb3 = pca.fit_transform(sc_emb3)
plt.plot(pc_emb3[:,0], pc_emb3[:,1], 'o')
np.where(pc_emb3[:,0] > 10)

# Embedding Features
emb4 = fn.embed_graphs(graphs, fast = True, method='features', dim = 20)
sc_emb4 = scaler.fit_transform(emb4)
pc_emb4 = pca.fit_transform(sc_emb4)
plt.plot(pc_emb4[:,0], pc_emb4[:,1], 'o')
np.where(pc_emb4[:,0] > 10)


# df = pd.DataFrame((pc_emb1[:,0],pc_emb1[:,1], pc_emb2[:,0],pc_emb2[:,1], pc_emb3[:,0], pc_emb3[:,1], pc_emb4[:,0], pc_emb4[:,1]))
np_emb =  np.column_stack((pc_emb1[:,0],pc_emb1[:,1], pc_emb2[:,0],pc_emb2[:,1], pc_emb3[:,0], pc_emb3[:,1], pc_emb4[:,0], pc_emb4[:,1]))
df_emb = pd.DataFrame(np_emb )
df_emb.to_csv('PC_Embeddings_Ex1.csv', index=False)






#%%
# These two figures are used in Figure 10 
emb_method = 4
temp_method = 1
anom_method = 2
anom, scores, shapley  = fn.graph_anomaly(graphs, 
                                         embedding_method = emb_method,
                                         embed_dim=20, 
                                         temporal_method = temp_method,
                                         anomaly_method = anom_method,
                                         doshap = True)

np.where(anom == -1)
plt.plot(scores)
plt.ylabel("Score")
plt.xlabel("Index")
plt.savefig('Exp1_Scores.pdf', dpi = 500,  bbox_inches='tight')
# Figure 10 (a)
len(anom)

shap.plots.bar(shapley)
shap.plots.bar(shapley[49], show=False)
plt.savefig('Exp1_Shap.pdf', dpi = 500,  bbox_inches='tight')
# Figure 10 (b)

# -----------------------------------------------------------------------------
# TASK  02: BARABASI GRAPH MODELS
# -----------------------------------------------------------------------------
#%%
import matplotlib.pyplot as plt
import Functions as fn
import networkx as nx
import random
import numpy as np
import shap
from sklearn.metrics import  roc_auc_score, roc_curve

random.seed(2013) 
graphs = [  nx.barabasi_albert_graph(n=100,m = 3)  for _ in range(100)]
graph_anom = nx.barabasi_albert_graph(n=100,m = 10)  
graphs[49] = graph_anom


ii = 0
anom_scores = np.zeros([100,56])
method_details = np.zeros([56,3])
for emb_method in range(1,5):
    for temp_method in range(1,3):
        for anom_method in range(1,8):
            anom, scores, shapley  = fn.graph_anomaly(graphs, 
                                                     embedding_method = emb_method,
                                                     embed_dim=20, 
                                                     temporal_method = temp_method,
                                                     anomaly_method = anom_method,
                                                     doshap = False)
            anom_scores[:,ii] = scores
            method_details[ii,:] = [emb_method, temp_method, anom_method]
            ii = ii + 1
            
np.savetxt("Barabasi_Anomaly_Different_Methods.csv", anom_scores, delimiter=",")
np.savetxt("Barabasi_Different_Methods.csv", method_details, delimiter=",")

true_scores =[0]*100
true_scores[49] = -1

roc_scores = [0]*56
for kk in range(56):
    roc_scores[kk] = roc_auc_score(true_scores, anom_scores[:,kk])
    
method_details2 = np.zeros([56,4])
method_details2[:,0:3] = method_details
method_details2[:,3] = roc_scores
np.savetxt("Barabasi_Anomaly_Results_Different_Methods.csv", method_details2, delimiter=",")


# Check embeddings 

scaler = StandardScaler()
pca = PCA()

# Embedding Graph2Vec
emb1 = fn.embed_graphs(graphs, fast = True, method='gl2vec', dim = 20)
sc_emb1 = scaler.fit_transform(emb1)
pc_emb1 = pca.fit_transform(sc_emb1)
plt.plot(pc_emb1[:,0], pc_emb1[:,1], 'o')
np.where(pc_emb1[:,0] > 4)


# Embedding FGSD
emb2 = fn.embed_graphs(graphs, fast = True, method='fgsd', dim = 20)
sc_emb2 = scaler.fit_transform(emb2)
pc_emb2 = pca.fit_transform(sc_emb2)
plt.plot(pc_emb2[:,0], pc_emb2[:,1], 'o')
np.where(pc_emb2[:,1] > 8)
np.where(pc_emb2[:,0] >10)


# Embedding graph2vec
emb3 = fn.embed_graphs(graphs, fast = True, method='graph2vec', dim = 20)
sc_emb3 = scaler.fit_transform(emb3)
pc_emb3 = pca.fit_transform(sc_emb3)
plt.plot(pc_emb3[:,0], pc_emb3[:,1], 'o')
np.where(pc_emb3[:,0] > 6)

# Embedding Features
emb4 = fn.embed_graphs(graphs, fast = True, method='features', dim = 20)
sc_emb4 = scaler.fit_transform(emb4)
pc_emb4 = pca.fit_transform(sc_emb4)
plt.plot(pc_emb4[:,0], pc_emb4[:,1], 'o')
np.where(pc_emb4[:,0] > 10)


# df = pd.DataFrame((pc_emb1[:,0],pc_emb1[:,1], pc_emb2[:,0],pc_emb2[:,1], pc_emb3[:,0], pc_emb3[:,1], pc_emb4[:,0], pc_emb4[:,1]))
np_emb =  np.column_stack((pc_emb1[:,0],pc_emb1[:,1], pc_emb2[:,0],pc_emb2[:,1], pc_emb3[:,0], pc_emb3[:,1], pc_emb4[:,0], pc_emb4[:,1]))
df_emb = pd.DataFrame(np_emb )
df_emb.to_csv('PC_Embeddings_Ex2.csv', index=False)





#%%
# The following 2 figures are used in Figure 13
random.seed(2013)
emb_method = 4
temp_method = 2
anom_method = 2
anom, scores, shapley  = fn.graph_anomaly(graphs, 
                                         embedding_method = emb_method,
                                         embed_dim=20, 
                                         temporal_method = temp_method,
                                         anomaly_method = anom_method,
                                         doshap = True)

np.where(anom == -1)
plt.plot(scores)
plt.ylabel("Score")
plt.xlabel("Index")
plt.savefig('Exp2_Scores.pdf', dpi = 500,  bbox_inches='tight')
# Figure 13 (a)

shap.plots.bar(shapley[49], show=False)
plt.savefig('Exp2_Shap.pdf', dpi = 500,  bbox_inches='tight')
# Figure 13 (b)

# -----------------------------------------------------------------------------
# TASK  03: WATTS-STROGATZ SMALL WORLD MODEL
# -----------------------------------------------------------------------------
#%%
import matplotlib.pyplot as plt
import Functions as fn
import networkx as nx
import random
import numpy as np
import shap
from sklearn.metrics import  roc_auc_score, roc_curve

random.seed(2013) 
graphs = [  nx.watts_strogatz_graph(n=100,k = 3, p = 0.5)  for _ in range(100)]
graph_anom = nx.watts_strogatz_graph(n=100,k = 6, p = 0.5)  #m = 6 had mixed results
graphs[49] = graph_anom


ii = 0
anom_scores = np.zeros([100,56])
method_details = np.zeros([56,3])
for emb_method in range(1,5):
    for temp_method in range(1,3):
        for anom_method in range(1,8):
            anom, scores, shapley  = fn.graph_anomaly(graphs, 
                                                     embedding_method = emb_method,
                                                     embed_dim=20, 
                                                     temporal_method = temp_method,
                                                     anomaly_method = anom_method,
                                                     doshap = False)
            anom_scores[:,ii] = scores
            method_details[ii,:] = [emb_method, temp_method, anom_method]
            ii = ii + 1
            
np.savetxt("WattsStrogatz_Anomaly_Different_Methods.csv", anom_scores, delimiter=",")
np.savetxt("WattsStrogatz_Different_Methods.csv", method_details, delimiter=",")

true_scores =[0]*100
true_scores[49] = -1

roc_scores = [0]*56
for kk in range(56):
    roc_scores[kk] = roc_auc_score(true_scores, anom_scores[:,kk])
    
method_details2 = np.zeros([56,4])
method_details2[:,0:3] = method_details
method_details2[:,3] = roc_scores
np.savetxt("WattsStrogatz_Anomaly_Results_Different_Methods.csv", method_details2, delimiter=",")


# Check embeddings 

scaler = StandardScaler()
pca = PCA()

# Embedding Graph2Vec
emb1 = fn.embed_graphs(graphs, fast = True, method='gl2vec', dim = 20)
sc_emb1 = scaler.fit_transform(emb1)
pc_emb1 = pca.fit_transform(sc_emb1)
plt.plot(pc_emb1[:,0], pc_emb1[:,1], 'o')
np.where(pc_emb1[:,0] > 4)


# Embedding FGSD
emb2 = fn.embed_graphs(graphs, fast = True, method='fgsd', dim = 20)
sc_emb2 = scaler.fit_transform(emb2)
pc_emb2 = pca.fit_transform(sc_emb2)
plt.plot(pc_emb2[:,0], pc_emb2[:,1], 'o')
np.where(pc_emb2[:,1] > 8)
np.where(pc_emb2[:,0] >10)


# Embedding graph2vec
emb3 = fn.embed_graphs(graphs, fast = True, method='graph2vec', dim = 20)
sc_emb3 = scaler.fit_transform(emb3)
pc_emb3 = pca.fit_transform(sc_emb3)
plt.plot(pc_emb3[:,0], pc_emb3[:,1], 'o')
np.where(pc_emb3[:,0] > 6)

# Embedding Features
emb4 = fn.embed_graphs(graphs, fast = True, method='features', dim = 20)
sc_emb4 = scaler.fit_transform(emb4)
pc_emb4 = pca.fit_transform(sc_emb4)
plt.plot(pc_emb4[:,0], pc_emb4[:,1], 'o')
np.where(pc_emb4[:,0] > 10)


# df = pd.DataFrame((pc_emb1[:,0],pc_emb1[:,1], pc_emb2[:,0],pc_emb2[:,1], pc_emb3[:,0], pc_emb3[:,1], pc_emb4[:,0], pc_emb4[:,1]))
np_emb =  np.column_stack((pc_emb1[:,0],pc_emb1[:,1], pc_emb2[:,0],pc_emb2[:,1], pc_emb3[:,0], pc_emb3[:,1], pc_emb4[:,0], pc_emb4[:,1]))
df_emb = pd.DataFrame(np_emb )
df_emb.to_csv('PC_Embeddings_Ex3.csv', index=False)

#%%
# The following two figures are used in Figure 16

emb_method = 4
temp_method = 1
anom_method = 1
anom, scores, shapley  = fn.graph_anomaly(graphs, 
                                         embedding_method = emb_method,
                                         embed_dim=20, 
                                         temporal_method = temp_method,
                                         anomaly_method = anom_method,
                                         doshap = True)

np.where(anom == -1)
shap.plots.bar(shapley[49])

plt.plot(scores)
plt.ylabel("Score")
plt.xlabel("Index")
plt.savefig('Exp3_Scores.pdf', dpi = 500,  bbox_inches='tight')
# Figure 16(a)

shap.plots.bar(shapley[49], show=False)
plt.savefig('Exp3_Shap.pdf', dpi = 500,  bbox_inches='tight')
# Figure 16 (b)
























