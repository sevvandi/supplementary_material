------------------------------------------------------------------------------------
Reproducing work in the paper "Anomaly Detection in Dynamic Networks".
------------------------------------------------------------------------------------

Overview
--------
The Python scripts contain the methodology and the SHAP visualisation.
The R scripts contain the visualisation of networks and the results visualisation. 
The Python scripts will write the output to csv files and these will be used by the R scripts.
For completeness, I have included the results csv files in this folder as well. 


Steps
-----

1. Download all files to a folder and make it the working folder.

2. The Twitter Security Dataset is available at https://odds.cs.stonybrook.edu/twittersecurity-dataset/  
Twitter_May_Aug_2014_TerrorSecurity_resolved.txt
It is 125 MB file and is not included on the GitHub repo. Please download this to the working directory.

3. First run Synthetic_Experiments.py. This will save some csv files. They will produce the results in Section 3.1. 

4. Next run Real_Examples.py. This will also save some csv files and these will produce the results in Section 3.2. 

5. Now we start running the R scripts. First run the Plotting_Synthetic_from_Framework.R

6. Then run Plotting_Real_Examples.R  

 


